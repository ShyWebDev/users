package com.dev.hobby.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCmdControllerApplicationTests {

    @Test
    void contextLoads() {
    }

}

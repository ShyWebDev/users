package com.dev.hobby.user.infrastructure.persistence.mysql.repository;

public class JpaUserRepository {
}

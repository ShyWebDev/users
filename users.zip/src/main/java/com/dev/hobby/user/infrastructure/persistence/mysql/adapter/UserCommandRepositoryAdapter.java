package com.dev.hobby.user.infrastructure.persistence.mysql.adapter;

public class UserCommandRepositoryAdapter {
}

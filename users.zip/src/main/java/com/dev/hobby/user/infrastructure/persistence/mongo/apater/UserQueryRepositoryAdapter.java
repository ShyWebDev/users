package com.dev.hobby.user.infrastructure.persistence.mongo.apater;

public class UserQueryRepositoryAdapter {
}
